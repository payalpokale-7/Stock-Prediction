<h1>Stock Price Prediction</h1>
<p>This is a simple stock price prediction model built using TensorFlow and Keras.</p>
<p>The model predicts the closing price of a stock using historical data.</p>

